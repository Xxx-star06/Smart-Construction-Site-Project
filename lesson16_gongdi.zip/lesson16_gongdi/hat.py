# _*_ coding: utf-8
# @Time : 2025/7/25 20:00
# @Author Xxx
# @File : hat
import json

# coding=utf-8

import requests
import os
from apig_sdk import signer
import cv2

def hat_check(img_path):

    # Config url, ak, sk and file path.
    #测试花卉
    url = "https://infer-modelarts-cn-north-4.modelarts-infer.com/v1/infers/34e7ba0f-f787-4cc7-b742-af2fadfd8209"
    ak = 'HPUAVTQE3EIP8IUQALAY'
    sk = '4mKOOlVyADNx1Nkt5wWSlDWB71Hm7VzRGOB1Sv8r'
    #花卉测试
    file_path = img_path

    # Create request, set method, url, headers and body.
    method = 'POST'
    headers = {"x-sdk-content-sha256": "UNSIGNED-PAYLOAD"}
    request = signer.HttpRequest(method, url, headers)

    # Create sign, set the AK/SK to sign and authenticate the request.
    sig = signer.Signer()
    sig.Key = ak
    sig.Secret = sk
    sig.Sign(request)

    # Send request
    files = {'images': open(file_path, 'rb')}
    resp = requests.request(request.method, request.scheme + "://" + request.host + request.uri, headers=request.headers, files=files)

    data_dict = json.loads(resp.text)
    print(data_dict)

    '''
    解析平台预测出来的数据，绘制到本地的图片
    使用opencv绘制内容
    解析数据格式
       json格式: {'key':'value','key2':'value2'}
    '''
    #解析json格式，获取数据
    data_dict = json.loads(resp.text)
    print(data_dict)
    return data_dict
















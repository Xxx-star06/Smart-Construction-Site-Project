# _*_ coding: utf-8
# @Time : 2025/7/25 22:35
# @Author Xxx
# @File : view
from PIL.ImageOps import scale
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPalette, QBrush, QPixmap, QImage
from PyQt5.QtWidgets import QWidget, QApplication, QVBoxLayout, QTextEdit, QLabel, QHBoxLayout, QPushButton
import sys
import cv2
#制作一个界面
#先垂直布局，分成两个部分，第二个部分水平布局，分为三个部分



class view(QWidget):
    def __init__(self,w = 1400, h = 900):
        super().__init__()
        self.w = w
        self.h = h
        #设置窗口属性
        self.resize(self.w,self.h)#设置窗口大小
        self.setWindowTitle("智慧工地")#设置窗口标题

        #设置背景
        palette = QPalette()
        palette.setBrush(self.backgroundRole(),QBrush(QPixmap('images/background.jpg').scaled(self.size())))
        self.setPalette(palette)
        #设置布局
        self.init_win_items()

    def init_win_items(self):
        '''
        初始化窗口的各个部件
        :return:
        '''
        #首先采用垂直布局，分成两个部分，第二个部分水平布局，分为三个部分
        #垂直布局
        main_layout = QVBoxLayout(self)
        QWidget1 = QWidget() #widget是容器，可以容纳其他控件
        QWidget2 = QWidget()
        no1_layout = QVBoxLayout(QWidget1)
        no2_layout = QHBoxLayout(QWidget2)
        #第二个部分水平布局
        #第一个部分是显示文本框
        self.acclable = QLabel("智慧工地--AI",self)
        #设置大小,位置
        self.acclable.setFixedSize(self.w, 100)
        #顶部
        self.acclable.setAlignment(Qt.AlignTop) #设置顶部
        #颜色
        self.acclable.setStyleSheet("color:white;font-size:28px; font-weight:bold;")
        self.acclable.setAlignment(Qt.AlignCenter) #设置居中
        #添加到第一个widget
        no1_layout.addWidget(self.acclable,alignment = Qt.AlignCenter)

        #第二个部分的第一个部分是Qlabel
        QLabel1 = QLabel(self)
        #放进到第二个widget
        no2_layout.addWidget(QLabel1, 1)#1表示占1份
        #Qlabel可以用来 、显示图片、文字、按钮等
        #第二个部分的为三个部分 左侧显示文字L检测视频格式，中间显示被检测的图片，右边是列表，QlistWidget
        #左边
        #显示文字 除了label
        left_layout = QVBoxLayout(self)
        no2_layout.addLayout(left_layout, 1)


        #多行
        text = """
        监控视频数：
        已检测视频数：
        未检测视频数：
        """
        left_label = QLabel(text,self)
        left_label.setFixedSize(self.w/3, 100)
        left_label.setStyleSheet("color:white;font-size:28px;")
        left_layout.addWidget(left_label)

        text = '''
        当前监控工地异常情况:
        无安全帽数:
        无穿反光衣服:
        '''
        left_label2 = QLabel(text,self)
        left_label2.setFixedSize(self.w/3, 100)
        left_label2.setStyleSheet("color:white;font-size:28px;")
        left_layout.addWidget(left_label2)

        #中间 用cv2读取一张图片，显示到QLabel,再次之前上上面右四个按钮
        media_lauout = QVBoxLayout(self)
        top_layout = QHBoxLayout(self)
        top_btn1 = QPushButton('播放',self)
        top_btn2 = QPushButton('暂停',self)
        top_btn3 = QPushButton('打开摄像头',self)
        top_btn4 = QPushButton('云检测',self)
        top_layout.addWidget(top_btn1)
        top_layout.addWidget(top_btn2)
        top_layout.addWidget(top_btn3)
        top_layout.addWidget(top_btn4)
        media_lauout.addLayout(top_layout)
        no2_layout.addLayout(media_lauout, 1)
            #读取一张图片
        img = cv2.imread('images/img.jpg')
        #转换成qt格式
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (int(self.w/3), int(self.h/3)))
        height, width, bytesPerComponent = img.shape
        bytesPerLine = bytesPerComponent * width
        qImg = QImage(img.data, width, height, bytesPerLine, QImage.Format_RGB888)
        #显示到QLabel
        QLabel1.setPixmap(QPixmap.fromImage(qImg))
        #添加到第二个widget
        media_lauout.addWidget(QLabel1)
        #右边
        #工地实时监控列表这是文字，下面是QlistWidget

        #工地监测监控列表在工地实时监控列表下面，这两个在右边垂直布局
        right_layout = QVBoxLayout(self)
        top_Text = QLabel("工地实时监控",self)
        top_Text.setStyleSheet("color:white;font-size:20px;")
        right_layout.addWidget(top_Text)
        no2_layout.addLayout(right_layout, 1)
        #列表下面是QlistWidget
        #工地实时监控列表
        self.listWidget1 = QTextEdit(self)
        self.listWidget1.setFixedSize(self.w/3, self.h/3)
        self.listWidget1.setReadOnly(True) #设置只读
        right_layout.addWidget(self.listWidget1)

        di_Text = QLabel("工地监测", self)
        di_Text.setFixedSize(self.w / 3, 50)
        right_layout.addWidget(di_Text)
        no2_layout.addLayout(right_layout, 1)
        #工地监测列表
        self.listWidget2 = QTextEdit(self)
        self.listWidget2.setFixedSize(self.w/3, self.h/3)
        self.listWidget2.setReadOnly(True) #设置只读
        right_layout.addWidget(self.listWidget2)
        di_Text.setStyleSheet("color:white;font-size:20px;")


        #将这两个QlistWidget添加到右边垂直布局
        #添加到第二个widget




        main_layout.addWidget(QWidget1, 1)  # 顶部占1份
        main_layout.addWidget(QWidget2, 3)  # 底部占3份


if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = view()
    w.show()
    sys.exit(app.exec_())

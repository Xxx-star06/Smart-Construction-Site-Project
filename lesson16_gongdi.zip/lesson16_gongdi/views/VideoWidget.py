# _*_ coding: utf-8
# @Time : 2025/7/27 14:12
# @Author Xxx
# @File : VideoWidget
import cv2,hat
import datetime
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSizePolicy, QLabel
import sys
from PyQt5.QtWidgets import QApplication
#视频操作显示的类
class VideoWidget(QWidget):
    signal_video = pyqtSignal()
    signal_cloud = pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)

        self.init_ui()
        #变量定义
        self.current_video_path ='./videos/工地.mp4' #当前需要播放的视频
        self.cap = cv2.VideoCapture(self.current_video_path)
        print(self.current_video_path)
        self.video_capture = None #视频对象
        self.video_capture_camera = cv2.VideoCapture(self.current_video_path) #摄像头对象

        self.is_camera_on = False #摄像头是否开启
        self.is_playing = False #判断是否播放视频
        #实例化定时器
        self.timer =QTimer() #配置估计事件执行某个方法
        #配置定时器需要执行的方法
        self.timer.timeout.connect(self.update_frame) #更新视频显示
        #视频输出
        self.video_writer = None
        self.recording_start_time = None #录制开始时间


        #视频播放
        self.timer2 = QTimer()
        self.timer2.timeout.connect(self.play_frame)
        #云检测
        self.time3 = QTimer()
        self.time3.timeout.connect(self.check_cloud)


        #按钮事件绑定
        self.btn_play.clicked.connect(self.on_play)
        self.btn_stop.clicked.connect(self.on_stop)
        self.btn_camera.clicked.connect(self.on_camera)
        self.btn_check.clicked.connect(self.on_cloud)

        self.show_video_first_frame(self.current_video_path)


    def on_play(self):
        print('播放')
        #判断是否存在文件
        if self.current_video_path and not self.is_playing:
            self.start_video()


    def on_stop(self):
        print('暂停')
        self.stop_video()

    def stop_video(self):
        print('停止播放')
        self.is_playing = False
        self.timer2.stop()
        if self.video_capture:
            self.video_capture.release()
            self.video_capture = None



    def on_camera(self):
        print('打开摄像头')
        #检测摄像头是否开启
        if not self.is_camera_on:
            self.start_camera()
        else:
            self.stop_camera()


    def start_video(self):
        '''
        视频当做一张张图片，一张张显示到label上
        只要配置画面来自视频文件即可
        :return:
        '''
        #先关闭摄像头
        self.stop_camera()
        try:
            self.stop_camera()  # 先关闭摄像头
            print('开始播放视频')
            self.video_capture = cv2.VideoCapture(self.current_video_path)
            if self.video_capture.isOpened():
                self.is_playing = True
                self.timer2.start(30)
            else:
                self.video_label.setText("无法打开视频")
        except Exception as e:
            print(e)




    def start_camera(self):
        """
        打开摄像头
        :return:
        """
        print("打开摄像头")
        if self.is_camera_on == True:
            self.stop_camera()
        self.video_capture = cv2.VideoCapture(0)
        #检查摄像头是否开启成功
        if self.video_capture.isOpened():
            self.is_camera_on = True
            #设置定时器
            self.timer.start(30) #每隔30ms更新一次视频显示 1000ms=1s
            self.btn_camera.setText('关闭摄像头')
            self.start_recording() #开始录制
        else:
            self.video_label.setText("无法打开视频")


    def play_frame(self):
        """
        更新视频显示
        获取最新摄像头的一帧画面
        BGR格式转RGB格式
        :return:
        """
        print('更新视频显示')
        if self.video_capture:
            ret, frame = self.video_capture.read()
            if ret: #如果视频没有结束
                frame_resized = cv2.resize(frame, (800, 600))
                #获取当前时间 格式化字符串
                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB, frame_resized)
                h,w,ch = frame_rgb.shape
                #在内存里面生成一种图片，比从文件夹里面读取快很多
                q_image = QImage(frame_rgb.data, w, h, ch * w, QImage.Format_RGB888)
                self.video_label.setPixmap(QPixmap.fromImage(q_image))


    def update_frame(self):
        """
        更新视频显示
        获取最新摄像头的一帧画面
        BGR格式转RGB格式
        :return:
        """
        print('2更新视频显示')
        if self.video_capture:
            ret, frame = self.video_capture.read()
            if ret: #如果视频没有结束
                frame_resized = cv2.resize(frame, (800, 600))
                #获取当前时间 格式化字符串
                now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                #把字符串写在画面左上角
                cv2.putText(frame_resized, now_str, (5, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (190, 190, 190), 2,cv2.LINE_AA)
                #设置录制时间20秒
                #如果超过20秒，则重新开始录制

                if self.recording_start_time and (datetime.datetime.now() - self.recording_start_time).total_seconds() >= 20:
                    diff_time = (datetime.datetime.now() - self.recording_start_time).total_seconds()

                    print(f'录制时间超过20秒，重新开始录制，已录制{diff_time}秒')
                    self.start_recording()
                if self.video_writer:
                    self.video_writer.write(frame_resized)

                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB, frame_resized)
                h,w,ch = frame_rgb.shape
                #在内存里面生成一种图片，比从文件夹里面读取快很多
                q_image = QImage(frame_rgb.data, w, h, ch * w, QImage.Format_RGB888)
                self.video_label.setPixmap(QPixmap.fromImage(q_image))



    def stop_camera(self): #开启之前先事释放之前操作的摄像头
        """
        关闭摄像头   释放资源
        :return:
        """
        self.is_camera_on = False
        self.timer.stop() #停止定时器
        self.timer2.stop() #停止定时器
        if self.video_capture:
            self.video_capture.release()
            self.video_capture = None
        if self.video_writer:
            self.video_writer.release()
            self.video_writer = None
            #设置按钮文字 恢复时间标记
            self.btn_camera.setText('打开摄像头')
            self.recording_start_time = None



    def start_recording(self):
        """
        开始录制
        :return:
        """
        if self.video_writer:
            self.video_writer.release()
        #设置视频编码对象
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        now = datetime.datetime.now()
        filename = now.strftime('%Y%m%d%H%M%S') + '.mp4'
        file_path = f'./videos/{filename}'
        self.video_writer = cv2.VideoWriter(file_path, fourcc, 20.0, (800, 600))
        #录制开始， 开始记录当前倒计时
        self.recording_start_time = now
        #个别情况下，由于资源短缺，导致视频格式出错，无法播放，但是文件夹中还是存在该文件
        #1.保存前判断是否满足20s或者可以播放的条件，满足就保存
        #2.先全部保存，当我读取列表时再判断是否有20s
        self.signal_video.emit() #发送信号，通知界面更新




    def on_cloud(self):
        '''
        云检测 把原来检查的图片的过程进行升级，把视频拆解成图片，然后进行检测
        检测画面中人有没有带安全帽
        1.读取视频，获取画面frame
        2.图片灰度转换，加快检测数据
        3.保存为缓存图片，华为云接收的参数是图片
        4.发送到华为云，接收返回的数据
        6.保存为视频
        7.没有视频就结束
        :return:
        '''
        #读取视频 输入是videos，输出是check_videos格式{原来文件名}.check.mp4
        #点击目录 播放 云检测
        file_name = self.current_video_path.split('/')[-1].split('.')[0]  # 正确获取文件名
        save_path = f'./check_videos/{file_name}_check.mp4'  # 输出路径
        finish_path = f'./finish_videos/{file_name}_finish.mp4'  # 输出路径
        #读取视频
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.video_writer = cv2.VideoWriter(save_path, fourcc, 20.0, (800, 600))
        #开启云检测定时器
        self.time3.start(30) #每隔






    def check_cloud(self):
        '''
        云检测
        :return:
        '''
        try:
        #读取路径current_video_path的视频
            ret, frame = self.cap.read()
            if ret:
                frame_resized = cv2.resize(frame, (800, 600))
                # 获取当前时间 格式化字符串
                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB, frame_resized)
                # 保存
                temp_path = 'images/temp.jpg'
                cv2.imwrite(temp_path, frame_rgb)  # 生成临时图片
                data_dict = hat.hat_check(temp_path)
                print(data_dict)
                #获取字典里面数据，检测多个安全帽
                label_list = data_dict['detection_classes']
                boxes_list = data_dict['detection_boxes']
                scores_list = data_dict['detection_scores']
                print(label_list,boxes_list,scores_list)
                for i in range(len(boxes_list)):
                    box = boxes_list[i]
                    y1, x1, y2, x2 = box[0],box[1],box[2],box[3]
                    y1 = int(float(y1))
                    x1 = int(float(x1))
                    y2 = int(float(y2))
                    x2 = int(float(x2))
                    label = label_list[i]
                    score = scores_list[i]
                    cv2.rectangle(frame_resized, (x1, y1), (x2, y2), (0, 255, 0), 1)
                    #绘制文本
                    text = f'{label}({score * 100:.2f}%)'
                    cv2.putText(frame_resized, text, (x1 + 8, y1 + 8), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2 )
                    #导出视频
                    self.video_writer.write(frame_resized)
                #显示视频
            else:
                self.time3.stop() #停止定时器
                self.video_writer.release() #关闭视频写入器
                print('视频播放完毕')
        except Exception as e:
            print(e)
            self.time3.stop() #停止定时器
            self.video_writer.release() #关闭视频写入器
            print('视频播放完毕')
            #发送信号，更新已经检测列表
            self.signal_cloud.emit() #发送信号，通知界面更新




    def show_video_first_frame(self, video_path):
        '''
        显示预览图
        :param video_path:
        :return:
        '''
        self.stop_camera()
        self.stop_video()
        self.current_video_path = video_path
        cap = cv2.VideoCapture(self.current_video_path)
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                frame_resized = cv2.resize(frame, (800, 600))
                # 获取当前时间 格式化字符串
                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB, frame_resized)
                h, w, ch = frame_rgb.shape
                # 在内存里面生成一种图片，比从文件夹里面读取快很多
                q_image = QImage(frame_rgb.data, w, h, ch * w, QImage.Format_RGB888)
                self.video_label.setPixmap(QPixmap.fromImage(q_image))
            cap.release()
        else:
            self.video_label.setText("无法打开视频")



    def init_ui(self):
        '''
        界面控件实例化
        :return:
        '''

        #主布局
        layout = QVBoxLayout()
        #按钮区域
        btn_layout = QHBoxLayout()
        self.btn_play = QPushButton('播放')
        self.btn_stop = QPushButton('暂停')
        self.btn_camera = QPushButton('打开摄像头')
        self.btn_check = QPushButton('云检查')
        for btn in [self.btn_play, self.btn_stop, self.btn_camera, self.btn_check]:
            btn.setMaximumWidth(100)
            #分布方式
            #参数 : 水平方向设置自动拉伸占满全部空间，垂直方向使用最小尺寸100
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn_layout.addWidget(btn)
        #添加到主布局
        layout.addLayout(btn_layout)


        #视频显示区域
        self.video_label = QLabel()
        self.video_label.setFixedSize(800, 600)
        self.video_label.setStyleSheet('''
        background: #2E1C7C;
        border:1px solid #2E1C7C;
        border-radius: 5px;
        ''')
        self.video_label.setAlignment(Qt.AlignCenter)
        #添加到主布局
        layout.addWidget(self.video_label)
        #设置主布局
        self.setLayout(layout)






# _*_ coding: utf-8
# @Time : 2025/7/30 20:12
# @Author Xxx
# @File : MainWidget
import os

from PyQt5.QtCore import Qt, QStringListModel
from PyQt5.QtGui import QPalette, QBrush, QPixmap, QImage, QIcon
from PyQt5.QtWidgets import QWidget, QApplication, QVBoxLayout, QTextEdit, QLabel, QHBoxLayout, QPushButton, QListView
import sys
import cv2
#制作一个界面
from views.VideoWidget import VideoWidget

class MainWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GongDi")
        self.resize(1300, 700)
        icon_path = 'images/background.jpg'
        self.setWindowIcon(QIcon(icon_path))

        self.setAutoFillBackground(True) # 设置背景图片
        palette = QPalette()
        bg_path = 'images/background.jpg'
        pixmap = QPixmap(bg_path).scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette.setBrush(QPalette.Window, QBrush(pixmap))
        self.setPalette(palette)

        #录制的视频路径
        self.video_path = './videos/'
        self.video_finish_path = './finish_videos/'
        self.check_video_path = './check_videos/'
        self.initUI()
        self.update_file_list()
        self.update_file_finish_list()










    def initUI(self):
        self.titleLb = QLabel('智慧工地',self)
        self.titleLb.setGeometry(560, 15, 300, 30)
        self.titleLb.setAlignment(Qt.AlignCenter)
        self.titleLb.setStyleSheet("font-size: 35px;color: white;")

        self.totalLayout = QHBoxLayout()
        self.setLayout(self.totalLayout)

        self.left = QVBoxLayout()
        self.mid = QVBoxLayout()
        self.right = QVBoxLayout()

        self.totalLayout.addLayout(self.left)
        self.totalLayout.addLayout(self.mid)
        self.totalLayout.addLayout(self.right)

        self.left1 = QLabel('监控视频数:4个\n已检测视频数：2个\n未检测视频数：2个',self)
        self.left2 = QLabel('当前监控工地异常：\n无安全帽\n无反光：8个',self)
        self.left1.setStyleSheet('color:white;padding : 10px; border-radius: 15px;')
        self.left2.setStyleSheet('color:white;padding : 10px; border-radius: 15px;')
        self.left.setContentsMargins(0, 30, 0, 0)
        self.left.addWidget(self.left1)
        self.left.addWidget(self.left2)

        self.video_widget = VideoWidget(self)
        self.video_widget.signal_video.connect(self.refresh_file_list)
        self.video_widget.signal_cloud.connect(self.refresh_file_finish_list)
        self.mid.addWidget(self.video_widget)
        self.mid.setContentsMargins(0, 30, 0, 0) #设置

        self.right1 = QLabel('工地实时监控列表',self)
        self.right2 = QLabel('工地简称为监控列表',self)
        self.right1.setStyleSheet('color:white; padding : 10px; border-radius: 5px;')
        self.right2.setStyleSheet('color:white; padding : 10px; border-radius: 5px;')
        #列表
        self.view1 =QListView()
        self.view2 =QListView()
        self.left.setContentsMargins(0, 30, 0, 0)


        self.right.addWidget(self.right1)
        self.right.addWidget(self.view1)
        self.right.addWidget(self.right2)
        self.right.addWidget(self.view2)
        self.right.setContentsMargins(0, 30, 0, 0)

        #设置占比
        self.totalLayout.setStretchFactor(self.left, 2)
        self.totalLayout.setStretchFactor(self.mid, 6)
        self.totalLayout.setStretchFactor(self.right, 2)
        #位置微调
        self.left.setContentsMargins(10, 30, 0, 0)
        self.mid.setContentsMargins(30, 30, 0, 0)
        self.right.setContentsMargins(0, 30, 0, 0)



    def refresh_file_finish_list(self):
        '''
        更新已检测文件列表
        :param self:
        :return:
        '''
        self.update_file_finish_list()

        # 绑定事件
        self.view2.clicked.connect(self.list_view_finish_click)

    def refresh_file_list(self):
        '''
        更新文件列表
        :param self:
        :return:
        '''
        self.update_file_list()


    def update_file_finish_list(self):
        self.video_finish_list = self.get_video_list(self.check_video_path)
        self.slm2 = QStringListModel()  # 数据模型
        self.slm2.setStringList(self.video_finish_list)  # 设置数据
        self.view2.setModel(self.slm2)  # 设置模型

        # 绑定事件
        self.view2.clicked.connect(self.list_view_finish_click)


    def update_file_list(self):
        '''
        更新列表
        :param self:
        :return:
        '''
        self.video_list = self.get_video_list(self.video_path)
        self.slm1 = QStringListModel() #数据模型
        self.slm1.setStringList(self.video_list)  #设置数据
        self.view1.setModel(self.slm1)  #设置模型

        #绑定事件
        self.view1.clicked.connect(self.list_view_click)

    def list_view_finish_click(self,item):
        '''
        已检测列表点击事件
        :return:
        '''
        index= item.row() #文件在列表中的下标
        filename = self.video_finish_list[index] #文件名
        path = self.video_finish_path + filename #文件路径
        print(path)
        #第一帧
        self.video_widget.show_video_first_frame(path)

    def list_view_click(self,item):
        '''
        列表点击事件
        QListview自带的item点击对象
        :return:
        '''
        index= item.row() #文件在列表中的下标
        filename = self.video_list[index] #文件名
        path = self.video_path + filename #文件路径
        print(path)
        #第一帧
        self.video_widget.show_video_first_frame(path)


# 更新列表 播放





    def get_video_list(self,path):
        '''
        获取视频列表
        :param self:
        :return:
        '''
        files = os.listdir(path) #获取path目录下所有文件名
        #最后加个文件过滤，只要后缀名.mp4的文件
        return files







if __name__ == '__main__':
    app = QApplication(sys.argv)
    main = MainWidget()
    main.show()
    sys.exit(app.exec_())
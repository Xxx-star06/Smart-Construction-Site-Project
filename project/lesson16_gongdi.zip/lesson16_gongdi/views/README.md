# 智慧工地

## 简介
本项目是基于pyqt5 + opencv实现视频播放，摄像头监控，云检测等功能，适用于智慧工地的视频管理和监控

## 主要功能
- 视频播放和暂停
- 摄像头监控（开启/关闭）
- 云端检测（上传视频，获取检测结果）
- 视频文件列表的操作(加载点击播放，删除)

## 依赖环境
- python3.7+
- pyqt5
- opencv-python
- requests


## 目录结构
- check_video  #存放已经检测的视频(mp4)
- videos       #录制的视频(mp4)
- views        #页面代码
- main.py      #主程序入口


## 运行方式
1. 安装依赖"pyqt5、opencv”
2. 运行main.py
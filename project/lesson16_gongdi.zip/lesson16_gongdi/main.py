# _*_ coding: utf-8
# @Time : 2025/7/27 16:40
# @Author Xxx
# @File : main
import sys

from PyQt5.QtWidgets import QApplication
from views.MainWidget import MainWidget


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main = MainWidget()
    main.show()
    sys.exit(app.exec_())
